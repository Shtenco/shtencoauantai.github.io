// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

interface IAavePoolV16 {
    function flashLoanSimple(
        address receiverAddress,
        address asset,
        uint256 amount,
        bytes calldata params,
        uint16 referralCode
    ) external;
}

interface IQuickSwapV2FactoryV16 {
    function getPair(address tokenA, address tokenB) external view returns (address pair);
}

interface IQuickSwapV3FactoryV16 {
    function poolByPair(address tokenA, address tokenB) external view returns (address pool);
}

interface IQuickSwapV2RouterV16 {
    function swapExactTokensForTokens(
        uint256 amountIn,
        uint256 amountOutMin,
        address[] calldata path,
        address to,
        uint256 deadline
    ) external returns (uint256[] memory amounts);
}

interface IAlgebraSwapRouterV16 {
    struct ExactInputSingleParams {
        address tokenIn;
        address tokenOut;
        address recipient;
        uint256 deadline;
        uint256 amountIn;
        uint256 amountOutMinimum;
        uint160 limitSqrtPrice;
    }

    function exactInputSingle(ExactInputSingleParams calldata params)
        external
        payable
        returns (uint256 amountOut);
}

contract ManagedSyntheticV16 is ERC20 {
    address public immutable admin;
    mapping(address => bool) public operator;

    error Unauthorized();

    constructor(string memory name_, string memory symbol_, address admin_)
        ERC20(name_, symbol_)
    {
        require(admin_ != address(0));
        admin = admin_;
        operator[admin_] = true;
    }

    function setOperator(address account, bool allowed) external {
        if (msg.sender != admin) revert Unauthorized();
        operator[account] = allowed;
    }

    function mint(address to, uint256 amount) external {
        if (!operator[msg.sender]) revert Unauthorized();
        _mint(to, amount);
    }

    function burn(address from, uint256 amount) external {
        if (!operator[msg.sender]) revert Unauthorized();
        _burn(from, amount);
    }
}

contract ManagedPoolV16 is ReentrancyGuard {
    using SafeERC20 for IERC20;

    uint256 public constant FEE_NUMERATOR = 997;
    uint256 public constant FEE_DENOMINATOR = 1000;

    IERC20 public immutable synthetic;
    IERC20 public immutable liquid;
    uint112 private reserveSynthetic;
    uint112 private reserveLiquid;

    error InvalidAmount();
    error InsufficientLiquidity();
    error Slippage();

    event Sync(uint112 reserveSynthetic, uint112 reserveLiquid);

    constructor(address synthetic_, address liquid_) {
        require(synthetic_ != address(0) && liquid_ != address(0));
        synthetic = IERC20(synthetic_);
        liquid = IERC20(liquid_);
    }

    function seed(uint256 syntheticAmount, uint256 liquidAmount) external nonReentrant {
        if (syntheticAmount == 0 || liquidAmount == 0) revert InvalidAmount();
        synthetic.safeTransferFrom(msg.sender, address(this), syntheticAmount);
        liquid.safeTransferFrom(msg.sender, address(this), liquidAmount);
        _sync();
    }

    function sync() external nonReentrant {
        _sync();
    }

    function getReserves() external view returns (uint112, uint112) {
        return (reserveSynthetic, reserveLiquid);
    }

    function quoteLiquidOut(uint256 syntheticIn) public view returns (uint256) {
        if (syntheticIn == 0) return 0;
        uint256 inWithFee = syntheticIn * FEE_NUMERATOR;
        return inWithFee * uint256(reserveLiquid)
            / (uint256(reserveSynthetic) * FEE_DENOMINATOR + inWithFee);
    }

    function quoteLiquidForExactSynthetic(uint256 syntheticOut)
        public
        view
        returns (uint256)
    {
        if (syntheticOut == 0 || syntheticOut >= reserveSynthetic) {
            revert InsufficientLiquidity();
        }
        uint256 numerator = uint256(reserveLiquid) * syntheticOut * FEE_DENOMINATOR;
        uint256 denominator = (uint256(reserveSynthetic) - syntheticOut) * FEE_NUMERATOR;
        return numerator / denominator + 1;
    }

    function swapExactSyntheticForLiquid(
        uint256 syntheticIn,
        uint256 minimumLiquidOut,
        address to
    ) external nonReentrant returns (uint256 liquidOut) {
        if (syntheticIn == 0) revert InvalidAmount();
        liquidOut = quoteLiquidOut(syntheticIn);
        if (liquidOut == 0 || liquidOut < minimumLiquidOut) revert Slippage();
        synthetic.safeTransferFrom(msg.sender, address(this), syntheticIn);
        liquid.safeTransfer(to, liquidOut);
        _sync();
    }

    function swapLiquidForExactSynthetic(
        uint256 syntheticOut,
        uint256 maximumLiquidIn,
        address to
    ) external nonReentrant returns (uint256 liquidIn) {
        liquidIn = quoteLiquidForExactSynthetic(syntheticOut);
        if (liquidIn > maximumLiquidIn) revert Slippage();
        liquid.safeTransferFrom(msg.sender, address(this), liquidIn);
        synthetic.safeTransfer(to, syntheticOut);
        _sync();
    }

    function _sync() internal {
        uint256 s = synthetic.balanceOf(address(this));
        uint256 l = liquid.balanceOf(address(this));
        if (s > type(uint112).max || l > type(uint112).max) revert InsufficientLiquidity();
        reserveSynthetic = uint112(s);
        reserveLiquid = uint112(l);
        emit Sync(reserveSynthetic, reserveLiquid);
    }
}

contract SolverAuctionV16 is ReentrancyGuard {
    struct Opportunity {
        bytes32 planHash;
        uint16 minTreasuryShareBps;
        uint64 closeBlock;
        uint64 expiryBlock;
        bool settled;
        bool consumed;
    }

    struct Bid {
        address solver;
        uint16 treasuryShareBps;
        uint128 bond;
        bytes32 solutionHash;
    }

    address public immutable coordinator;
    address public immutable treasury;
    uint128 public immutable minimumBond;
    address public consumer;
    uint256 public currentEpoch;

    mapping(uint256 => Opportunity) public opportunities;
    mapping(uint256 => Bid) public best;
    mapping(address => uint256) public refunds;

    error Unauthorized();
    error InvalidOpportunity();
    error InvalidBid();
    error NotReady();
    error InvalidSolution();

    constructor(address coordinator_, address treasury_, uint128 minimumBond_) {
        require(coordinator_ != address(0) && treasury_ != address(0) && minimumBond_ > 0);
        coordinator = coordinator_;
        treasury = treasury_;
        minimumBond = minimumBond_;
    }

    function setConsumer(address consumer_) external {
        if (msg.sender != treasury || consumer != address(0) || consumer_ == address(0)) {
            revert Unauthorized();
        }
        consumer = consumer_;
    }

    function publish(
        bytes32 planHash,
        uint16 minTreasuryShareBps,
        uint64 closeBlock,
        uint64 expiryBlock
    ) external returns (uint256 epoch) {
        if (msg.sender != coordinator) revert Unauthorized();
        if (
            planHash == bytes32(0) || minTreasuryShareBps == 0
                || minTreasuryShareBps >= 10_000 || closeBlock <= block.number
                || expiryBlock <= closeBlock
        ) revert InvalidOpportunity();
        epoch = ++currentEpoch;
        opportunities[epoch] = Opportunity({
            planHash: planHash,
            minTreasuryShareBps: minTreasuryShareBps,
            closeBlock: closeBlock,
            expiryBlock: expiryBlock,
            settled: false,
            consumed: false
        });
    }

    function bid(uint256 epoch, bytes32 solutionHash, uint16 treasuryShareBps)
        external
        payable
        nonReentrant
    {
        Opportunity storage op = opportunities[epoch];
        if (op.planHash == bytes32(0) || block.number > op.closeBlock || op.settled) {
            revert NotReady();
        }
        if (
            solutionHash != op.planHash || treasuryShareBps < op.minTreasuryShareBps
                || treasuryShareBps >= 10_000 || msg.value < minimumBond
        ) revert InvalidBid();
        Bid storage current = best[epoch];
        bool leading = current.solver == address(0)
            || treasuryShareBps > current.treasuryShareBps
            || (treasuryShareBps == current.treasuryShareBps && msg.value > current.bond);
        if (leading) {
            if (current.solver != address(0)) refunds[current.solver] += current.bond;
            best[epoch] = Bid(msg.sender, treasuryShareBps, uint128(msg.value), solutionHash);
        } else {
            refunds[msg.sender] += msg.value;
        }
    }

    function settle(uint256 epoch) external {
        Opportunity storage op = opportunities[epoch];
        if (
            op.planHash == bytes32(0) || op.settled || block.number <= op.closeBlock
                || block.number > op.expiryBlock || best[epoch].solver == address(0)
        ) revert NotReady();
        op.settled = true;
    }

    function consume(uint256 epoch, bytes32 planHash, address solver)
        external
        returns (uint16 treasuryShareBps)
    {
        if (msg.sender != consumer) revert Unauthorized();
        Opportunity storage op = opportunities[epoch];
        Bid storage winner = best[epoch];
        if (
            !op.settled || op.consumed || block.number > op.expiryBlock
                || op.planHash != planHash || winner.solutionHash != planHash
                || winner.solver != solver
        ) revert InvalidSolution();
        op.consumed = true;
        treasuryShareBps = winner.treasuryShareBps;
        refunds[winner.solver] += winner.bond;
        winner.bond = 0;
    }

    function withdrawRefund() external nonReentrant {
        uint256 amount = refunds[msg.sender];
        if (amount == 0) revert InvalidBid();
        refunds[msg.sender] = 0;
        (bool ok,) = msg.sender.call{value: amount}("");
        require(ok);
    }
}

contract MidasRiskVetoV16 {
    struct Approval {
        uint256 maxCustomerUsdt;
        uint256 maxGradient;
        uint256 maxTemporaryQe;
        uint256 maxInternalLossUsdt;
        uint256 maxGasReserveUsdt;
        uint256 minProtocolProfitUsdt;
        uint256 minSolverProfitUsdt;
        uint64 expiry;
        bool consumed;
    }

    address public immutable governor;
    address public engine;
    mapping(bytes32 => Approval) public approvals;

    error Unauthorized();
    error RiskVeto();

    constructor(address governor_) {
        require(governor_ != address(0));
        governor = governor_;
    }

    function setEngine(address engine_) external {
        if (msg.sender != governor || engine != address(0) || engine_ == address(0)) {
            revert Unauthorized();
        }
        engine = engine_;
    }

    function approve(bytes32 planHash, Approval calldata approval) external {
        if (msg.sender != governor) revert Unauthorized();
        if (
            planHash == bytes32(0) || approval.maxCustomerUsdt == 0
                || approval.maxGradient == 0 || approval.maxTemporaryQe == 0
                || approval.maxInternalLossUsdt == 0 || approval.maxGasReserveUsdt == 0
                || approval.minProtocolProfitUsdt == 0 || approval.minSolverProfitUsdt == 0
                || approval.expiry <= block.timestamp
        ) revert RiskVeto();
        approvals[planHash] = approval;
    }

    function consume(
        bytes32 planHash,
        uint256 customerUsdt,
        uint256 gradient,
        uint256 temporaryQe,
        uint256 maxInternalLossUsdt,
        uint256 gasReserveUsdt,
        uint256 minProtocolProfitUsdt,
        uint256 minSolverProfitUsdt
    ) external {
        if (msg.sender != engine) revert Unauthorized();
        Approval storage a = approvals[planHash];
        if (
            a.consumed || block.timestamp > a.expiry
                || customerUsdt > a.maxCustomerUsdt || gradient > a.maxGradient
                || temporaryQe > a.maxTemporaryQe
                || maxInternalLossUsdt > a.maxInternalLossUsdt
                || gasReserveUsdt > a.maxGasReserveUsdt
                || minProtocolProfitUsdt < a.minProtocolProfitUsdt
                || minSolverProfitUsdt < a.minSolverProfitUsdt
        ) revert RiskVeto();
        a.consumed = true;
    }
}

contract GradientOpportunityMarketV16 is ReentrancyGuard {
    using SafeERC20 for IERC20;

    uint8 public constant VENUE_V2 = 2;
    uint8 public constant VENUE_V3 = 3;
    uint256 public constant MAX_HOPS = 4;
    uint256 public constant BPS = 10_000;

    struct Leg {
        uint8 venue;
        address pool;
        address tokenIn;
        address tokenOut;
        uint256 minOut;
    }

    struct Plan {
        bytes32 sourceId;
        uint256 nonce;
        uint256 deadline;
        address customer;
        uint256 customerUsdtIn;
        uint256 customerWpolOut;
        uint256 flashWpol;
        uint256 maxPremiumWpol;
        uint256 gradientShift;
        uint256 temporaryQe;
        uint256 minInternalWpolOut;
        uint256 maxBuybackUsdt;
        uint256 externalUsdtIn;
        uint256 gasReserveUsdt;
        uint256 solverGasReserveUsdt;
        uint256 maxInternalLossUsdt;
        uint256 minProtocolProfitUsdt;
        uint256 minSolverProfitUsdt;
        uint256 wpolPriceUsdtX18;
        Leg[] legs;
    }

    IAavePoolV16 public immutable aavePool;
    IERC20 public immutable wpol;
    IERC20 public immutable usdt;
    ManagedSyntheticV16 public immutable syna;
    ManagedPoolV16 public immutable sourcePool;
    ManagedPoolV16 public immutable destinationPool;
    SolverAuctionV16 public immutable auction;
    MidasRiskVetoV16 public immutable riskVeto;
    IQuickSwapV2RouterV16 public immutable v2Router;
    IAlgebraSwapRouterV16 public immutable v3Router;
    IQuickSwapV2FactoryV16 public immutable v2Factory;
    IQuickSwapV3FactoryV16 public immutable v3Factory;
    address public immutable treasury;
    bytes32 public immutable topologyHash;

    address[10] public internalPools;
    mapping(uint256 => bool) public nonceUsed;
    mapping(bytes32 => bool) public sourceUsed;

    bool private active;
    bytes32 private activePlanHash;
    uint16 private activeTreasuryShareBps;
    uint256 private sourceLiquidBefore;
    uint256 private destinationLiquidBefore;
    uint256 private supplyBefore;

    uint256 public temporaryOutstanding;
    uint256 public completedCycles;
    uint256 public lastPremiumWpol;
    uint256 public lastInternalWpolOut;
    uint256 public lastBuybackUsdt;
    uint256 public lastExternalWpolOut;
    uint256 public lastSolverRevenueUsdt;
    uint256 public lastTreasuryRevenueUsdt;
    uint256 public lastInternalValueLossUsdt;
    int256 public lastProtocolDeltaBeforeGasUsdt;
    int256 public lastProtocolNetAfterGasUsdt;
    uint256 public lastWpolSurplus;

    error InvalidPlan();
    error Replay();
    error InvalidCallback();
    error PremiumAboveCap();
    error RouteMismatch();
    error InsufficientFunds();
    error TemporarySupplyNotClosed();
    error InternalLossAboveCap();
    error ProtocolProfitBelowFloor();
    error SolverProfitBelowFloor();
    error Residue();

    event GradientOpportunitySettled(
        bytes32 indexed sourceId,
        uint256 indexed nonce,
        address indexed solver,
        address customer,
        uint256 customerUsdtIn,
        uint256 customerWpolOut,
        uint256 flashWpol,
        uint256 premiumWpol,
        uint256 internalWpolOut,
        uint256 buybackUsdt,
        uint256 externalWpolOut,
        uint256 solverRevenueUsdt,
        uint256 treasuryRevenueUsdt,
        uint256 internalValueLossUsdt,
        int256 protocolNetAfterGasUsdt
    );

    constructor(
        address aavePool_,
        address wpol_,
        address usdt_,
        address syna_,
        address sourcePool_,
        address destinationPool_,
        address auction_,
        address riskVeto_,
        address v2Router_,
        address v3Router_,
        address v2Factory_,
        address v3Factory_,
        address treasury_,
        address[10] memory internalPools_
    ) {
        if (
            aavePool_ == address(0) || wpol_ == address(0) || usdt_ == address(0)
                || syna_ == address(0) || sourcePool_ == address(0)
                || destinationPool_ == address(0) || auction_ == address(0)
                || riskVeto_ == address(0) || v2Router_ == address(0)
                || v3Router_ == address(0) || v2Factory_ == address(0)
                || v3Factory_ == address(0) || treasury_ == address(0)
        ) revert InvalidPlan();
        for (uint256 i; i < internalPools_.length; ++i) {
            if (internalPools_[i] == address(0) || internalPools_[i].code.length == 0) {
                revert InvalidPlan();
            }
            for (uint256 j; j < i; ++j) {
                if (internalPools_[i] == internalPools_[j]) revert InvalidPlan();
            }
        }
        bool sourceFound;
        bool destinationFound;
        for (uint256 i; i < internalPools_.length; ++i) {
            sourceFound = sourceFound || internalPools_[i] == sourcePool_;
            destinationFound = destinationFound || internalPools_[i] == destinationPool_;
        }
        if (!sourceFound || !destinationFound) revert InvalidPlan();

        aavePool = IAavePoolV16(aavePool_);
        wpol = IERC20(wpol_);
        usdt = IERC20(usdt_);
        syna = ManagedSyntheticV16(syna_);
        sourcePool = ManagedPoolV16(sourcePool_);
        destinationPool = ManagedPoolV16(destinationPool_);
        auction = SolverAuctionV16(auction_);
        riskVeto = MidasRiskVetoV16(riskVeto_);
        v2Router = IQuickSwapV2RouterV16(v2Router_);
        v3Router = IAlgebraSwapRouterV16(v3Router_);
        v2Factory = IQuickSwapV2FactoryV16(v2Factory_);
        v3Factory = IQuickSwapV3FactoryV16(v3Factory_);
        treasury = treasury_;
        internalPools = internalPools_;
        topologyHash = keccak256(abi.encode(internalPools_));
    }

    function hashPlan(Plan calldata plan) public view returns (bytes32) {
        return keccak256(abi.encode(block.chainid, address(this), plan));
    }

    function run(uint256 epoch, Plan calldata plan) external nonReentrant {
        if (active || block.timestamp > plan.deadline) revert InvalidPlan();
        if (
            plan.sourceId == bytes32(0) || plan.customer == address(0)
                || plan.customerUsdtIn == 0 || plan.customerWpolOut == 0
                || plan.flashWpol == 0 || plan.customerWpolOut > plan.flashWpol
                || plan.maxPremiumWpol == 0 || plan.gradientShift == 0
                || plan.temporaryQe == 0 || plan.minInternalWpolOut == 0
                || plan.maxBuybackUsdt == 0 || plan.externalUsdtIn == 0
                || plan.gasReserveUsdt == 0 || plan.solverGasReserveUsdt == 0
                || plan.maxInternalLossUsdt == 0 || plan.minProtocolProfitUsdt == 0
                || plan.minSolverProfitUsdt == 0 || plan.wpolPriceUsdtX18 == 0
        ) revert InvalidPlan();
        if (nonceUsed[plan.nonce] || sourceUsed[plan.sourceId]) revert Replay();
        _validateRoute(plan.legs);

        bytes32 planHash = hashPlan(plan);
        uint16 treasuryShareBps = auction.consume(epoch, planHash, msg.sender);
        riskVeto.consume(
            planHash,
            plan.customerUsdtIn,
            plan.gradientShift,
            plan.temporaryQe,
            plan.maxInternalLossUsdt,
            plan.gasReserveUsdt,
            plan.minProtocolProfitUsdt,
            plan.minSolverProfitUsdt
        );

        nonceUsed[plan.nonce] = true;
        sourceUsed[plan.sourceId] = true;
        usdt.safeTransferFrom(plan.customer, address(this), plan.customerUsdtIn);

        (, uint112 sourceLiquid) = sourcePool.getReserves();
        (, uint112 destinationLiquid) = destinationPool.getReserves();
        sourceLiquidBefore = sourceLiquid;
        destinationLiquidBefore = destinationLiquid;
        supplyBefore = syna.totalSupply();

        syna.burn(address(sourcePool), plan.gradientShift);
        syna.mint(address(destinationPool), plan.gradientShift);
        sourcePool.sync();
        destinationPool.sync();

        activePlanHash = planHash;
        activeTreasuryShareBps = treasuryShareBps;
        active = true;
        aavePool.flashLoanSimple(
            address(this), address(wpol), plan.flashWpol, abi.encode(plan, msg.sender), 0
        );
        active = false;
        activePlanHash = bytes32(0);
        activeTreasuryShareBps = 0;

        if (usdt.balanceOf(address(this)) != 0 || wpol.balanceOf(address(this)) != 0) {
            revert Residue();
        }
    }

    function executeOperation(
        address asset,
        uint256 amount,
        uint256 premium,
        address initiator,
        bytes calldata params
    ) external returns (bool) {
        if (
            msg.sender != address(aavePool) || !active || initiator != address(this)
                || asset != address(wpol)
        ) revert InvalidCallback();
        (Plan memory plan, address solver) = abi.decode(params, (Plan, address));
        if (
            keccak256(abi.encode(block.chainid, address(this), plan)) != activePlanHash
                || amount != plan.flashWpol || block.timestamp > plan.deadline
        ) revert InvalidCallback();
        if (premium > plan.maxPremiumWpol) revert PremiumAboveCap();
        if (wpol.balanceOf(address(this)) != amount) revert InvalidCallback();

        wpol.safeTransfer(plan.customer, plan.customerWpolOut);

        temporaryOutstanding = plan.temporaryQe;
        syna.mint(address(this), plan.temporaryQe);
        IERC20(address(syna)).forceApprove(address(sourcePool), plan.temporaryQe);
        uint256 internalWpolOut = sourcePool.swapExactSyntheticForLiquid(
            plan.temporaryQe, plan.minInternalWpolOut, address(this)
        );

        uint256 buybackUsdt = destinationPool.quoteLiquidForExactSynthetic(plan.temporaryQe);
        if (buybackUsdt > plan.maxBuybackUsdt) revert InsufficientFunds();
        usdt.forceApprove(address(destinationPool), buybackUsdt);
        uint256 syntheticBought = destinationPool.swapLiquidForExactSynthetic(
            plan.temporaryQe, plan.maxBuybackUsdt, address(this)
        );
        if (syntheticBought != buybackUsdt) revert InsufficientFunds();
        syna.burn(address(this), plan.temporaryQe);
        temporaryOutstanding = 0;

        uint256 externalWpolOut = _executeRoute(
            plan.externalUsdtIn, plan.legs, plan.deadline
        );

        syna.mint(address(sourcePool), plan.gradientShift);
        syna.burn(address(destinationPool), plan.gradientShift);
        sourcePool.sync();
        destinationPool.sync();

        if (syna.totalSupply() != supplyBefore || temporaryOutstanding != 0) {
            revert TemporarySupplyNotClosed();
        }

        uint256 repayment = amount + premium;
        uint256 wpolBalance = wpol.balanceOf(address(this));
        if (wpolBalance < repayment) revert InsufficientFunds();
        uint256 wpolSurplus = wpolBalance - repayment;

        uint256 remainingUsdt = usdt.balanceOf(address(this));
        uint256 solverRevenue = remainingUsdt * (BPS - activeTreasuryShareBps) / BPS;
        uint256 treasuryRevenue = remainingUsdt - solverRevenue;
        if (solverRevenue <= plan.solverGasReserveUsdt) revert SolverProfitBelowFloor();
        if (solverRevenue - plan.solverGasReserveUsdt < plan.minSolverProfitUsdt) {
            revert SolverProfitBelowFloor();
        }

        (, uint112 sourceLiquidAfter) = sourcePool.getReserves();
        (, uint112 destinationLiquidAfter) = destinationPool.getReserves();
        int256 sourceDeltaUsdt = _wpolDeltaToUsdt(
            int256(uint256(sourceLiquidAfter)) - int256(sourceLiquidBefore),
            plan.wpolPriceUsdtX18
        );
        int256 destinationDeltaUsdt =
            int256(uint256(destinationLiquidAfter)) - int256(destinationLiquidBefore);
        int256 poolDeltaUsdt = sourceDeltaUsdt + destinationDeltaUsdt;
        uint256 internalValueLoss = poolDeltaUsdt < 0 ? uint256(-poolDeltaUsdt) : 0;
        if (internalValueLoss > plan.maxInternalLossUsdt) revert InternalLossAboveCap();

        uint256 wpolSurplusUsdt = uint256(
            _wpolDeltaToUsdt(int256(wpolSurplus), plan.wpolPriceUsdtX18)
        );
        int256 protocolDeltaBeforeGas = poolDeltaUsdt
            + int256(treasuryRevenue)
            + int256(wpolSurplusUsdt);
        int256 protocolNetAfterGas = protocolDeltaBeforeGas - int256(plan.gasReserveUsdt);
        if (protocolNetAfterGas < int256(plan.minProtocolProfitUsdt)) {
            revert ProtocolProfitBelowFloor();
        }

        if (solverRevenue > 0) usdt.safeTransfer(solver, solverRevenue);
        if (treasuryRevenue > 0) usdt.safeTransfer(treasury, treasuryRevenue);
        if (wpolSurplus > 0) wpol.safeTransfer(treasury, wpolSurplus);
        wpol.forceApprove(address(aavePool), repayment);

        lastPremiumWpol = premium;
        lastInternalWpolOut = internalWpolOut;
        lastBuybackUsdt = buybackUsdt;
        lastExternalWpolOut = externalWpolOut;
        lastSolverRevenueUsdt = solverRevenue;
        lastTreasuryRevenueUsdt = treasuryRevenue;
        lastInternalValueLossUsdt = internalValueLoss;
        lastProtocolDeltaBeforeGasUsdt = protocolDeltaBeforeGas;
        lastProtocolNetAfterGasUsdt = protocolNetAfterGas;
        lastWpolSurplus = wpolSurplus;
        completedCycles += 1;

        emit GradientOpportunitySettled(
            plan.sourceId,
            plan.nonce,
            solver,
            plan.customer,
            plan.customerUsdtIn,
            plan.customerWpolOut,
            amount,
            premium,
            internalWpolOut,
            buybackUsdt,
            externalWpolOut,
            solverRevenue,
            treasuryRevenue,
            internalValueLoss,
            protocolNetAfterGas
        );
        return true;
    }

    function _executeRoute(uint256 amountIn, Leg[] memory legs, uint256 deadline)
        private
        returns (uint256 amountOut)
    {
        amountOut = amountIn;
        for (uint256 i; i < legs.length; ++i) {
            Leg memory leg = legs[i];
            address router = leg.venue == VENUE_V2 ? address(v2Router) : address(v3Router);
            IERC20(leg.tokenIn).forceApprove(router, amountOut);
            if (leg.venue == VENUE_V2) {
                address[] memory path = new address[](2);
                path[0] = leg.tokenIn;
                path[1] = leg.tokenOut;
                uint256[] memory amounts = v2Router.swapExactTokensForTokens(
                    amountOut, leg.minOut, path, address(this), deadline
                );
                amountOut = amounts[amounts.length - 1];
            } else {
                amountOut = v3Router.exactInputSingle(
                    IAlgebraSwapRouterV16.ExactInputSingleParams({
                        tokenIn: leg.tokenIn,
                        tokenOut: leg.tokenOut,
                        recipient: address(this),
                        deadline: deadline,
                        amountIn: amountOut,
                        amountOutMinimum: leg.minOut,
                        limitSqrtPrice: 0
                    })
                );
            }
            IERC20(leg.tokenIn).forceApprove(router, 0);
        }
    }

    function _validateRoute(Leg[] calldata legs) private view {
        if (legs.length < 2 || legs.length > MAX_HOPS) revert RouteMismatch();
        if (legs[0].tokenIn != address(usdt) || legs[legs.length - 1].tokenOut != address(wpol)) {
            revert RouteMismatch();
        }
        for (uint256 i; i < legs.length; ++i) {
            Leg calldata leg = legs[i];
            if (
                leg.pool == address(0) || leg.tokenIn == address(0) || leg.tokenOut == address(0)
                    || leg.tokenIn == leg.tokenOut || leg.minOut == 0
            ) revert RouteMismatch();
            if (i > 0 && legs[i - 1].tokenOut != leg.tokenIn) revert RouteMismatch();
            address expected;
            if (leg.venue == VENUE_V2) {
                expected = v2Factory.getPair(leg.tokenIn, leg.tokenOut);
            } else if (leg.venue == VENUE_V3) {
                expected = v3Factory.poolByPair(leg.tokenIn, leg.tokenOut);
            } else {
                revert RouteMismatch();
            }
            if (expected == address(0) || expected != leg.pool || expected.code.length == 0) {
                revert RouteMismatch();
            }
            for (uint256 j; j < i; ++j) {
                if (legs[j].pool == leg.pool) revert RouteMismatch();
            }
        }
    }

    function _wpolDeltaToUsdt(int256 wpolDelta, uint256 priceUsdtX18)
        private
        pure
        returns (int256)
    {
        return wpolDelta * int256(priceUsdtX18) / int256(1e30);
    }
}
